import argparse
import time

from DQN import *
from ActionTeacher import *
import pandas as pd
from evalute_net import *
from Evaluate_Net import *
from processing_library import *
parser = argparse.ArgumentParser()
parser.add_argument('-d', '--data_name', type=str, default='Indian_pines', help='train_dataset')
parser.add_argument('-s', '--step', default=90, type=int, help='run steps')
parser.add_argument('-beta', '--beta', default=10, type=int, help='weight of CORR when calculating r_list')
parser.add_argument('-teacher', '--teacher', default='filter', type=str, help='select_teacher')
args = parser.parse_args()

if args.teacher == 'filter':  # KBest
    action_teacher = FilterAdvisor
elif args.teacher == 'Wrapper':  # KBT
    action_teacher = WrapperAdvisor
elif args.teacher == 'Embedding':  # DTT
    action_teacher = EmbeddingAdvisor

elif args.teacher == 'MIX':  # Hybrid Teaching
    action_teacher = MIXAdvisor

else:
    action_teacher = None

# 读取数据

start = time.time()
data_norm, labels_ori, x_train, y_train, train_loc, x_test, y_test, test_loc = load_data(args.data_name)
# DQN params
BATCH_SIZE = 16
LR = 0.01
EPSILON = 0.9
GAMMA = 0.9
TARGET_REPLACE_ITER = 10
MEMORY_CAPACITY = int(args.step / 2)
N_ACTIONS = 2
BETA = args.beta

N_STATES = len(x_train)
# N_STATES = 9225

N_feature = x_train.shape[1]
N_sample = x_train.shape[0]

np.random.seed(0)
action_list = np.random.randint(2, size=N_feature)
select_number = [idx for idx, item in enumerate(action_list) if item == 1]
x_selected = x_train[:, action_list == 1]

# s = get_s(x_selected.T, np.array(select_number), N_STATES)
# 初始精度
# Evaluate = Trainer()
# accuracy, s = Evaluate.test()
# accuracy, s = get_acc(data_norm, labels_ori, y_train, train_loc, y_test, test_loc, select_number)
ret = RET(action_list, data_norm, labels_ori, y_train, train_loc)
accuracy, s = ret.acc, ret.s

# print('Initial_accuracy:' + str(accuracy))
x_test = pd.DataFrame(x_test)
ave_corr = x_test.corr().abs().sum().sum() / (x_test.shape[0] * x_test.shape[1])
r_list = (accuracy - BETA * ave_corr) / sum(action_list) * action_list
action_list_p = action_list

dqn_list = []
for agent in range(N_feature):
    dqn_list.append(DQN(N_STATES, N_ACTIONS, BATCH_SIZE, LR, EPSILON, GAMMA, TARGET_REPLACE_ITER, MEMORY_CAPACITY))


f = open('temp.txt', 'a+')
f.write('Creating sample' + '\n')
f.close()
best_acc = 0
for i in range(args.step):
    # print('Step:' + str(i))
    if i == 1:
        t = time.time()
        print('第一轮时间' + str(t-start) + '\n')
    if i == 50:
        training = time.time()
        print('训练时间' + str(training - start) + '\n')
    if i == 51:
        t = time.time()
        print('推理一轮时间' + str(t - training) + '\n')

    action_list = np.zeros(N_feature)
    for agent, dqn in enumerate(dqn_list):
        action_list[agent] = dqn.choose_action(s)

    if action_teacher is not None and i % 2 == 0 and i < MEMORY_CAPACITY + 1:
        if args.teacher != 'MIX':
            if args.teacher == 'KB':
                temp = action_teacher(action_list_p, action_list, pd.DataFrame(x_train), y_train)
            else:
                temp = action_teacher(action_list_p, action_list, pd.DataFrame(x_train), y_train,
                                      data_norm, labels_ori, y_test, test_loc)
        else:
            temp = action_teacher(action_list_p, action_list, pd.DataFrame(x_train), y_train,
                                  i, MEMORY_CAPACITY, data_norm, labels_ori, y_test, test_loc)

        # print('Advise! Advise Number: ' + str(N_feature - np.sum(temp == action_list)))
        # index = [idx for idx, item in enumerate(temp) if item != action_list[idx]]
        # print('Advise Index:' + str(index))
        # print('band_number:' + str(sum(action_list == 1)))
        # f = open('temp.txt', 'a+')
        # f.write('Step:' + str(i) + '\n')
        # f.write('Advise Number:' + str(N_feature - np.sum(temp == action_list)) + '\n')
        # f.write('select_number:' + str(sum(action_list == 1)) + '\n')
        # f.close()
        # action_list = temp

    x_selected = x_train[:, action_list == 1]
    select_number = [idx for idx, item in enumerate(action_list) if item == 1]

    # s_ = get_s(x_selected.T, np.array(select_number), N_STATES)
    # accuracy = get_acc(data_norm, labels_ori, y_train, train_loc, y_test, test_loc, select_number)
    ret = RET(action_list, data_norm, labels_ori, y_train, train_loc)
    accuracy, s_ = ret.acc, ret.s

    ave_corr = x_test.corr().abs().sum().sum() / (x_test.shape[0] * x_test.shape[1])
    r_list = (accuracy - BETA * ave_corr) / sum(action_list) * action_list

    # if i < MEMORY_CAPACITY + 1:
    #     print(str(accuracy) + str(sum(r_list)))
    # f = open('temp.txt', 'a+')
    # f.write('Accuracy:' + str(accuracy) + ' ')
    # f.write('Reward:' + str(sum(r_list)) + '\n')

    for agent, dqn in enumerate(dqn_list):
        dqn.store_transition(s,
                             action_list[agent],
                             r_list[agent],
                             s_)

    if dqn_list[0].memory_counter > MEMORY_CAPACITY:

        for dqn in dqn_list:
            dqn.learn()
        # f = open('temp.txt', 'a+')
        # f.write('reward_total:' + str(sum(r_list)) + ' ' + 'accuracy:' + str(accuracy) + '\n')
        # f.write('select_number:' + str(sum(action_list == 1)) + '\n')
        # f.close()

        # if accuracy > best_acc:
        #     best_acc = accuracy
        #     current_best_band = [idx for idx, item in enumerate(action_list) if item == 1]
        #     f = open('band.txt', 'a+')
        #     f.write('current step:' + str(i) + ' ' + '\n')
        #     f.write('accuracy:' + str(accuracy) + ' ' + 'band_number:' + str(len(current_best_band)) + '\n')
        #     f.write('band_combination:' + str(current_best_band) + '\n')

        # print(sum(r_list), accuracy)
        # print('select_number:' + str(sum(action_list == 1)))

    s = s_
    action_list_p = action_list
end = time.time()
print('整体运行时间' + str(end - start))
