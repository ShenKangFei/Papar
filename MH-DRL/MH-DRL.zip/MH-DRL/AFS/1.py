import argparse
import time

from DQN import *
from ActionTeacher import *
import pandas as pd
from evalute_net import *
from Evaluate_Net import *
from processing_library import *

a = np.array([[1, 2], [3, 4]])


a.corrpass
