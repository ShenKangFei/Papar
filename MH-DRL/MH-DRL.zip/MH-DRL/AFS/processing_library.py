# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 20:38:39 2018

@author: Jian tong Chen
"""

import os
import numpy as np
import scipy.io as sio
from sklearn.decomposition import PCA
import torch
import pandas as pd
from sklearn import preprocessing
import numpy as np
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
import torch
import torch.utils.data
import scipy.io as sio
import torch.utils.data
import os
import random


def load_data(data_name):
    """读取数据"""
    path = os.getcwd()
    pre = sio.loadmat(path + '/data/' + data_name +
                      '/' + data_name + '_pre.mat')

    data_norm = pre['data_norm']
    labels_ori = pre['labels_ori']
    x_train = pre['train_x']
    y_train = pre['train_y'][0]
    train_loc = pre['train_loc']
    x_test = pre['test_x']
    y_test = pre['test_y'][0]
    test_loc = pre['test_loc']
    y_val = pre["val_y"][0]
    val_loc = pre["val_loc"]
    # ulab_loc = pre['Ulab_loc']

    return data_norm, labels_ori, x_train, y_train, train_loc, x_test, y_test, test_loc


def one_hot(label, class_number):
    """转变标签形式"""
    one_hot_array = np.zeros([len(label), class_number])
    for i in range(len(label)):
        one_hot_array[i, int(label[i] - 1)] = 1
    return one_hot_array


def disorder(X, Y):
    """打乱顺序"""
    index_train = np.arange(X.shape[0])
    np.random.shuffle(index_train)
    X = X[index_train, :]
    Y = Y[index_train, :]
    return X, Y


def next_batch(image, label, index, batch_size):
    """数据分批"""
    start = index - batch_size
    end = index
    return image[start:end, :], label[start:end]


def contrary_one_hot(label):
    """将one_hot标签转化为真实标签"""
    size = len(label)
    label_ori = np.empty(size)
    for i in range(size):
        label_ori[i] = np.argmax(label[i])
    return label_ori


def expend(data, w):
    size = data.shape
    data_extend = np.zeros((int(size[0] + w - 1), int(size[1] + w - 1), size[2]))
    for j in range(size[2]):
        data_extend[:, :, j] = np.lib.pad(data[:, :, j], ((
                                                              int(w / 2), int(w / 2)), (int(w / 2), int(w / 2))),
                                          'symmetric')
    return data_extend


def pca_trans_extend(data, n, w):
    """PCA + extend
    Args:
        data: input data, size like (W,H,b)
        n : n_components of PCA, a integer number
        w : width of patch_size, a odd number
    """
    data_reshape = data.reshape((-1, data.shape[2]))
    pca = PCA(n_components=n)
    data_pca = pca.fit_transform(data_reshape)
    data_reshape_2 = data_pca.reshape([data.shape[0], data.shape[1], -1])
    data_ex = expend(data_reshape_2, w)
    return data_ex


def data_3dto2d(dataset):
    H, W, L = dataset.shape
    data = np.zeros((H * W, L))
    for h in range(H):
        for w in range(W):
            data[h * W + w] = dataset[h, w, :]
    return data


def random_cut_bands(data):
    """
    随机选择波段集合
    """

    select_band = np.random.choice(range(200), 100, replace=False)
    data[:, select_band, :, :] = 0
    return data


def windowFeature(data_expand, loc, w):
    newdata = np.zeros([loc.shape[0], w, w, data_expand.shape[2]])
    for i in range(loc.shape[0]):
        x1 = loc[i, 0]
        y1 = loc[i, 1]
        x2 = loc[i, 0] + w
        y2 = loc[i, 1] + w
        c = data_expand[x1:x2, y1:y2, :]
        newdata[i, :, :, :] = c
    return newdata


def select(data, action_list):
    for i in action_list:
        if i == 1:
            data[:, :, i] = 0
    return data, i


def applyPCA(X, numComponents):
    newX = np.reshape(X, (-1, X.shape[2]))
    pca = PCA(n_components=numComponents, whiten=True)
    newX = pca.fit_transform(newX)
    newX = np.reshape(newX, (X.shape[0], X.shape[1], numComponents))
    return newX


# 对单个像素周围提取 patch 时，边缘像素就无法取了，因此，给这部分像素进行 padding 操作
def padWithZeros(X, margin=2):
    newX = np.zeros((X.shape[0] + 2 * margin, X.shape[1] + 2 * margin, X.shape[2]))
    x_offset = margin
    y_offset = margin
    newX[x_offset:X.shape[0] + x_offset, y_offset:X.shape[1] + y_offset, :] = X
    return newX


# 在每个像素周围提取 patch ，然后创建成符合 keras 处理的格式
def createImageCubes(X, y, windowSize=5, removeZeroLabels=True):
    # 给 X 做 padding
    margin = int((windowSize - 1) / 2)
    zeroPaddedX = padWithZeros(X, margin=margin)
    # split patches
    patchesData = np.zeros((X.shape[0] * X.shape[1], windowSize, windowSize, X.shape[2]))
    patchesLabels = np.zeros((X.shape[0] * X.shape[1]))
    patchIndex = 0
    for r in range(margin, zeroPaddedX.shape[0] - margin):
        for c in range(margin, zeroPaddedX.shape[1] - margin):
            patch = zeroPaddedX[r - margin:r + margin + 1, c - margin:c + margin + 1]
            patchesData[patchIndex, :, :, :] = patch
            patchesLabels[patchIndex] = y[r - margin, c - margin]
            patchIndex = patchIndex + 1
    if removeZeroLabels:
        patchesData = patchesData[patchesLabels > 0, :, :, :]
        patchesLabels = patchesLabels[patchesLabels > 0]
        patchesLabels -= 1
    return patchesData, patchesLabels


def splitTrainTestSet(X, y, testRatio, randomState):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=testRatio, random_state=randomState, stratify=y)
    return X_train, X_test, y_train, y_test


def get_test(data, test_ratio, patch_size, pca_components):
    X = sio.loadmat('data/Indian_pines/Indian_pines_corrected.mat')['indian_pines_corrected']
    y = sio.loadmat('data/Indian_pines/Indian_pines_gt.mat')['indian_pines_gt']

    X_pca = applyPCA(X, numComponents=pca_components)

    X_pca, y = createImageCubes(X_pca, y, windowSize=patch_size)

    X_train, X_test, y_train, y_test = splitTrainTestSet(X_pca, y, test_ratio, randomState=345)
    X_test = X_test.reshape(-1, patch_size, patch_size, pca_components, 1)
    X_test = X_test.transpose(0, 4, 3, 1, 2)
    test_set = TestDS(X_test, y_test)
    test_loader = torch.utils.data.DataLoader(dataset=test_set, batch_size=128, shuffle=False)
    return test_loader, y_test


""" Training dataset"""


class TrainDS(torch.utils.data.Dataset):
    def __init__(self, X_train, y_train):
        self.len = X_train.shape[0]
        self.x_data = torch.FloatTensor(X_train)
        self.y_data = torch.LongTensor(y_train)

    def __getitem__(self, index):
        # 根据索引返回数据和对应的标签
        return self.x_data[index], self.y_data[index]

    def __len__(self):
        # 返回文件数据的数目
        return self.len


""" Testing dataset"""


class TestDS(torch.utils.data.Dataset):
    def __init__(self, X_test, y_test):
        self.len = X_test.shape[0]
        self.x_data = torch.FloatTensor(X_test)
        self.y_data = torch.LongTensor(y_test)

    def __getitem__(self, index):
        # 根据索引返回数据和对应的标签
        return self.x_data[index], self.y_data[index]

    def __len__(self):
        # 返回文件数据的数目
        return self.len
