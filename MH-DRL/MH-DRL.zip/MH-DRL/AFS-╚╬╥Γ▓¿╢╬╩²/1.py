from evalute_net import *
import numpy as np
import random

c = list(range(10))
b = []
b =c
a = RET()
print(a.acc)
