# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 20:38:39 2018

@author: Jian tong Chen
"""

import os
import numpy as np
import scipy.io as sio
from sklearn.decomposition import PCA
import torch
import pandas as pd
from sklearn import preprocessing


def load_data(data_name):
    """读取数据"""
    path = os.getcwd()
    pre = sio.loadmat(path + '/data/' + data_name +
                      '/' + data_name + '_pre.mat')

    data_norm = pre['data_norm']
    labels_ori = pre['labels_ori']
    x_train = pre['train_x']
    y_train = pre['train_y'][0]
    train_loc = pre['train_loc']
    x_test = pre['test_x']
    y_test = pre['test_y'][0]
    test_loc = pre['test_loc']
    y_val = pre["val_y"][0]
    val_loc = pre["val_loc"]
    # ulab_loc = pre['Ulab_loc']

    return data_norm, labels_ori, x_train, y_train, train_loc, x_test, y_test, test_loc


def one_hot(label, class_number):
    """转变标签形式"""
    one_hot_array = np.zeros([len(label), class_number])
    for i in range(len(label)):
        one_hot_array[i, int(label[i] - 1)] = 1
    return one_hot_array


def disorder(X, Y):
    """打乱顺序"""
    index_train = np.arange(X.shape[0])
    np.random.shuffle(index_train)
    X = X[index_train, :]
    Y = Y[index_train, :]
    return X, Y


def next_batch(image, label, index, batch_size):
    """数据分批"""
    start = index - batch_size
    end = index
    return image[start:end, :], label[start:end]


def contrary_one_hot(label):
    """将one_hot标签转化为真实标签"""
    size = len(label)
    label_ori = np.empty(size)
    for i in range(size):
        label_ori[i] = np.argmax(label[i])
    return label_ori


def expend(data, w):
    size = data.shape
    data_extend = np.zeros((int(size[0] + w - 1), int(size[1] + w - 1), size[2]))
    for j in range(size[2]):
        data_extend[:, :, j] = np.lib.pad(data[:, :, j], ((
                                                              int(w / 2), int(w / 2)), (int(w / 2), int(w / 2))),
                                          'symmetric')
    return data_extend


def pca_trans_extend(data, n, w):
    """PCA + extend
    Args:
        data: input data, size like (W,H,b)
        n : n_components of PCA, a integer number
        w : width of patch_size, a odd number
    """
    data_reshape = data.reshape((-1, data.shape[2]))
    pca = PCA(n_components=n)
    data_pca = pca.fit_transform(data_reshape)
    data_reshape_2 = data_pca.reshape([data.shape[0], data.shape[1], -1])
    data_ex = expend(data_reshape_2, w)
    return data_ex


def data_3dto2d(dataset):
    H, W, L = dataset.shape
    data = np.zeros((H * W, L))
    for h in range(H):
        for w in range(W):
            data[h * W + w] = dataset[h, w, :]
    return data


def random_cut_bands(data):
    """
    随机选择波段集合
    """

    select_band = np.random.choice(range(200), 100, replace=False)
    data[:, select_band, :, :] = 0
    return data


def windowFeature(data_expand, loc, w):
    newdata = np.zeros([loc.shape[0], w, w, data_expand.shape[2]])
    for i in range(loc.shape[0]):
        x1 = loc[i, 0]
        y1 = loc[i, 1]
        x2 = loc[i, 0] + w
        y2 = loc[i, 1] + w
        c = data_expand[x1:x2, y1:y2, :]
        newdata[i, :, :, :] = c
    return newdata

