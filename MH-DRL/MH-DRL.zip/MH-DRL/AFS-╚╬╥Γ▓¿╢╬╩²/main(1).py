import argparse
from DQN import *
from ActionTeacher import *
import pandas as pd
from evalute_net import *
from processing_library import *

parser = argparse.ArgumentParser()
parser.add_argument('-d', '--data_name', type=str, default='Indian_pines', help='train_dataset')
parser.add_argument('-s', '--step', default=10, type=int, help='run steps')
parser.add_argument('-beta', '--beta', default=10, type=int, help='weight of CORR when calculating r_list')
parser.add_argument('-teacher', '--teacher', default='', type=str, help='select_teacher')
parser.add_argument('-num', '--band_number', default=70, type=int, help='total_band_number')
args = parser.parse_args()

if args.teacher == 'filter':  # KBT
    action_teacher = KBestAdvisor()
elif args.teacher == 'Wrapper':  # KBT
    action_teacher = WrapperAdvisor
elif args.teacher == 'RFC':  # DTT
    action_teacher = RFCAdvisor
elif args.teacher == 'RFE':  # Hybrid Teaching
    action_teacher = RFEAdvisor
elif args.teacher == 'MIX':  # Hybrid Teaching
    action_teacher = MIXAdvisor
elif args.teacher == 'Wrapper':  # KBT
    action_teacher = WrapperAdvisor
else:
    action_teacher = None

# 读取数据
data_norm, labels_ori, x_train, y_train, train_loc, x_test, y_test, test_loc = load_data(args.data_name)

# DQN params
BATCH_SIZE = 16
LR = 0.01
EPSILON = 0.9
GAMMA = 0.9
TARGET_REPLACE_ITER = 100
MEMORY_CAPACITY = int(args.step / 2)
N_ACTIONS = 2
BETA = args.beta
N_STATES = 144
N_feature = x_train.shape[1]
N_sample = x_train.shape[0]

# Initial_action
band_number = args.band_number
action_list = np.zeros(N_feature)
initial_list = [0] * N_feature
initial_index = random.sample(initial_list, band_number)
for i in initial_index:
    action_list[i] = 1
cur_number = sum(action_list == 1)
select_number = [idx for idx, item in enumerate(action_list) if item == 1]
x_selected = x_train[:, action_list == 1]

# 初始精度
ret = RET(action_list, data_norm, labels_ori, y_test, test_loc)
accuracy, s = ret.acc, ret.s
# accuracy = get_acc(data_norm, labels_ori, y_train, train_loc, y_test, test_loc, select_number)
print('Initial_accuracy:' + str(accuracy))
x_test = pd.DataFrame(x_test)
ave_corr = x_test.corr().abs().sum().sum() / (x_test.shape[0] * x_test.shape[1])
alpha = accuracy - BETA * ave_corr
band_constraint = (alpha * ((cur_number - band_number) ** 2)) / ((N_feature - band_number) ** 2)
r_list = (alpha - band_constraint) / sum(action_list) * action_list
action_list_p = action_list

dqn_list = []
for agent in range(N_feature):
    dqn_list.append(DQN(N_STATES, N_ACTIONS, BATCH_SIZE, LR, EPSILON, GAMMA, TARGET_REPLACE_ITER, MEMORY_CAPACITY))

f = open('temp.txt', 'a+')
f.write('Creating sample' + '\n')
f.close()
best_acc = 0
for i in range(args.step):
    print('Step:' + str(i))
    action_list = np.zeros(N_feature)
    action_value = []
    for agent, dqn in enumerate(dqn_list):
        action_list[agent], value = dqn.choose_action(s)
        action_value.append(value)
    value_index = np.argsort(-np.array(action_value))
    value_index = value_index[:band_number]
    action_list = np.zeros(N_feature)
    for j in list(value_index):
        action_list[j] = 1

    if action_teacher is not None and i % 2 == 0 and i < MEMORY_CAPACITY + 1:
        if args.teacher != 'MIX':
            if args.teacher == 'KB':
                temp = action_teacher(action_list_p, action_list, pd.DataFrame(x_train), y_train)
            else:
                temp = action_teacher(action_list_p, action_list, pd.DataFrame(x_train), y_train,
                                      data_norm, labels_ori, y_test, test_loc)
        else:
            temp = action_teacher(action_list_p, action_list, pd.DataFrame(x_train), y_train,
                                  i, MEMORY_CAPACITY, data_norm, labels_ori, y_test, test_loc)

        print('Advise! Advise Number: ' + str(N_feature - np.sum(temp == action_list)))
        index = [idx for idx, item in enumerate(temp) if item != action_list[idx]]
        print('Advise Index:' + str(index))
        print('band_number:' + str(sum(action_list == 1)))
        f = open('temp.txt', 'a+')
        f.write('Step:' + str(i) + '\n')
        f.write('Advise Number:' + str(N_feature - np.sum(temp == action_list)) + '\n')
        f.write('select_number:' + str(sum(action_list == 1)) + '\n')
        f.close()
        action_list = temp

    x_selected = x_train[:, action_list == 1]
    select_number = [idx for idx, item in enumerate(action_list) if item == 1]

    # s_ = get_s(x_selected.T, np.array(select_number), N_STATES)
    # accuracy = get_acc(data_norm, labels_ori, y_train, train_loc, y_test, test_loc, select_number)
    ret = RET(action_list, data_norm, labels_ori, y_train, train_loc)
    accuracy, s_ = ret.acc, ret.s

    cur_number = sum(action_list == 1)
    print('select_number:' + str(cur_number))
    ave_corr = x_test.corr().abs().sum().sum() / (x_test.shape[0] * x_test.shape[1])
    alpha = accuracy - BETA * ave_corr
    band_constraint = (alpha * ((cur_number - band_number) ** 2)) / ((N_feature - band_number) ** 2)
    r_list = (alpha - band_constraint) / sum(action_list) * action_list

    if i < MEMORY_CAPACITY + 1:
        print(str(accuracy) + str(sum(r_list)))
    f = open('temp.txt', 'a+')
    f.write('Accuracy:' + str(accuracy) + ' ')
    f.write('Reward:' + str(sum(r_list)) + '\n')

    for agent, dqn in enumerate(dqn_list):
        dqn.store_transition(s,
                             action_list[agent],
                             r_list[agent],
                             s_)

    if dqn_list[0].memory_counter > MEMORY_CAPACITY:
        for dqn in dqn_list:
            dqn.learn()
        f = open('temp.txt', 'a+')
        f.write('reward_total:' + str(sum(r_list)) + ' ' + 'accuracy:' + str(accuracy) + '\n')
        f.write('select_number:' + str(sum(action_list == 1)) + '\n')
        f.close()

        if accuracy > best_acc:
            best_acc = accuracy
            current_best_band = [idx for idx, item in enumerate(action_list) if item == 1]
            f = open('band.txt', 'a+')
            f.write('current step:' + str(i) + ' ' + '\n')
            f.write('accuracy:' + str(accuracy) + ' ' + 'band_number:' + str(len(current_best_band)) + '\n')
            f.write('band_combination:' + str(current_best_band) + '\n')

        print(sum(r_list), accuracy)
        print('select_number:' + str(sum(action_list == 1)))

    s = s_
    action_list_p = action_list
    pass
