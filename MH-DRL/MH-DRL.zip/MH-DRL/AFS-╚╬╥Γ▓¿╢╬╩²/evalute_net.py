import torch
import os
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import cohen_kappa_score
from processing_library import one_hot, disorder
from processing_library import contrary_one_hot, expend
from net import Net
import torch.nn as nn

os.environ["CUDA_VISIBLE_DEVICES"] = '1'


class RET:
    def __init__(self, select_band, data_norm, labels_ori, y_test, test_loc):

        selected_bands = select_band
        selected_bands = [i for i in range(
            selected_bands.shape[0]) if selected_bands[i] == 1]
        data_norm_new = np.zeros_like(data_norm)
        #
        for i in selected_bands:  # .tolist():
            data_norm_new[:, :, i] = data_norm[:, :, i]
        data_norm = data_norm_new
        nrows, ncols, ndim = data_norm.shape

        num_classification = int(np.max(labels_ori))  # 类别数
        w = 31  # 图像块大小

        data_norm = expend(data_norm, w)

        ###############################################################################
        # load data
        Y_test = one_hot(y_test, num_classification)
        test_loc, Y_test = disorder(test_loc, Y_test)
        ###############################################################################
        data_norm = torch.tensor(data_norm, dtype=torch.float32).cuda()
        # ulab_loc = torch.tensor(ulab_loc, dtype=torch.int32).cuda()
        ###############################################################################
        new_data = torch.zeros(
            [1024, w, w, data_norm.shape[2]]).cuda()

        def get_oa(data, X_valid_loc, Y_valid):
            # X_valid_loc = X_valid_loc.transpose()

            size = np.shape(X_valid_loc)
            num = size[0]
            index_all = 0
            step_ = 200
            y_pred = []
            while index_all < num:
                if index_all + step_ > num:
                    input_loc = X_valid_loc[index_all:, :]
                else:
                    input_loc = X_valid_loc[index_all:(index_all + step_), :]
                input = _windowFeature_torch(data, input_loc, w).permute(
                    0, 3, 1, 2)
                # x = random_cut_bands(x)
                #        input = torch.tensor(x, dtype=torch.float32).cuda()
                #        input = input.reshape([input.shape[0],input.shape[1],input.shape[2],input.shape[3],1])
                index_all += step_

                temp1, _ = net(input)
                y_pred1 = contrary_one_hot(temp1.cpu()).astype('int32')
                y_pred.extend(y_pred1)
            y = contrary_one_hot(Y_valid).astype('int32')
            return y_pred, y

        def _windowFeature_torch(data_expand, loc, w, new_data=new_data):
            new_data = torch.zeros_like(new_data)
            for i in range(loc.shape[0]):
                x1 = loc[i, 0]  # 没错！
                y1 = loc[i, 1]
                x2 = loc[i, 0] + w
                y2 = loc[i, 1] + w
                c = data_expand[x1:x2, y1:y2, :]
                new_data[i, :, :, :] = c
            return new_data[:loc.shape[0], :, :, :]

        net = Net(input_bands=ndim, num_classification=num_classification)
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        net.to(device)
        if os.path.isdir('checkpoint'):
            try:
                checkpoint = torch.load('./checkpoint/Indian_pines.t7')
                net.load_state_dict(checkpoint['state'])  # 从字典中依次读取
            except FileNotFoundError:
                print('Can\'t found net.t7')

        ##############################################################################

        with torch.no_grad():
            y_pr, y_real = get_oa(data_norm, test_loc, Y_test)
            fc = nn.Linear(len(y_pr), 144)
            state = fc(torch.from_numpy(np.array(y_pr)).float())
            self.s = state.detach().numpy().flatten()
            oa = accuracy_score(y_real, y_pr)
            self.acc = oa
            per_class_acc = recall_score(y_real, y_pr, average=None)
            aa = np.mean(per_class_acc)
            kappa = cohen_kappa_score(y_real, y_pr)
            self.results = [oa, aa, kappa] + per_class_acc.tolist()
