import argparse
from GCN import *
from DQN import *
from ActionTeacher import *
from data_process import *

# ignore warning outputs
import warnings
warnings.filterwarnings("ignore")

parser = argparse.ArgumentParser()
parser.add_argument('-d', '--data_name', type=str, default='clean', help='train_dataset')
parser.add_argument('-s', '--step', default=100, type=int, help='run steps')
parser.add_argument('-beta', '--beta', default=10, type=int, help='weight of CORR when calculating r_list')
parser.add_argument('-model', '--model', default='DT', type=str, help='downstream task cannot change here')
parser.add_argument('-teacher', '--teacher', default='KB', type=str, help='select_teacher')

args = parser.parse_args()

# pretrain data
dataset = ReadData(args.data_name)
r, c = dataset.shape
array = dataset.values
X = dataset.iloc[:, 0:(c - 1)]
Y = dataset.iloc[:, (c - 1)]
X_train, X_val, Y_train, Y_val = model_selection.train_test_split(X, Y, test_size=0.95, random_state=0)

model = DecisionTreeClassifier()

if args.teacher == 'KB':  # KBT
    action_teacher = KBestAdvisor
elif args.teacher == 'DT':  # DTT
    action_teacher = DTAdvisor
elif args.teacher == 'MIX':  # Hybrid Teaching
    action_teacher = MIXAdvisor
else:
    action_teacher = None

print(model)
print(action_teacher)

# feature number
N_feature = X_train.shape[1]
# feature length,i.e., sample number
N_sample = X_train.shape[0]
# DQN params
BATCH_SIZE = 8
LR = 0.01
EPSILON = 0.9
GAMMA = 0.9
TARGET_REPLACE_ITER = 10
MEMORY_CAPACITY = int(args.step / 2)
N_ACTIONS = 2
N_STATES = len(X_train)
BETA = args.beta

# initialize
np.random.seed(0)
action_list = np.random.randint(2, size=N_feature)

X_selected = X_train.iloc[:, action_list == 1]
model.fit(X_train.iloc[:, action_list == 1], Y_train)
s = Feature_GCN(X_selected)

accuracy = model.score(X_val.iloc[:, action_list == 1], Y_val)
ave_corr = X_val.corr().abs().sum().sum() / (X_val.shape[0] * X_val.shape[1])
r_list = (accuracy - BETA * ave_corr) / sum(action_list) * action_list

action_list_p = action_list
dqn_list = []
for agent in range(N_feature):
    dqn_list.append(DQN(N_STATES, N_ACTIONS, BATCH_SIZE, LR, EPSILON, GAMMA, TARGET_REPLACE_ITER, MEMORY_CAPACITY))

f = open('temp.txt', 'a+')
f.truncate(0)
f.write('Creating sample' + '\n')
f.close()

for i in range(args.step):
    if i % (args.step / 10) == 0:
        print(i)

    action_list = np.zeros(N_feature)
    for agent, dqn in enumerate(dqn_list):
        action_list[agent] = dqn.choose_action(s)

    if action_teacher is not None and i % 2 == 0 and i < MEMORY_CAPACITY + 1:
        if args.teacher != 'MIX':
            temp = action_teacher(action_list_p, action_list, X_train, Y_train)
        else:
            temp = action_teacher(action_list_p, action_list, X_train, Y_train, i, MEMORY_CAPACITY)

        print('Advise! Advise Number: ' + str(N_feature - np.sum(temp == action_list)))
        f = open('temp.txt', 'a+')
        f.write('Advise Number:' + str(N_feature - np.sum(temp == action_list)) + '\n')
        f.close()
        action_list = temp

    X_selected = X_train.iloc[:, action_list == 1]
    model.fit(X_train.iloc[:, action_list == 1], Y_train)
    s_ = Feature_GCN(X_selected)

    accuracy = model.score(X_val.iloc[:, action_list == 1], Y_val)
    ave_corr = X_val.iloc[:, action_list == 1].corr().abs().sum().sum() / (
                X_val.iloc[:, action_list == 1].shape[0] * X_val.iloc[:, action_list == 1].shape[1])
    r_list = (accuracy - BETA * ave_corr) / sum(action_list) * action_list

    # storage samples to memory buffer
    for agent, dqn in enumerate(dqn_list):
        dqn.store_transition(s, action_list[agent], r_list[agent], s_)

    # update DQN parameters
    if dqn_list[0].memory_counter > MEMORY_CAPACITY:
        for dqn in dqn_list:
            dqn.learn()
        f = open('temp.txt', 'a+')
        f.write(str(sum(r_list)) + ' ' + str(accuracy) + '\n')
        f.write(str(model.predict(X_val.iloc[:, action_list == 1])) + '\n')
        f.close()
        print(sum(r_list), accuracy)

    s = s_
    action_list_p = action_list
