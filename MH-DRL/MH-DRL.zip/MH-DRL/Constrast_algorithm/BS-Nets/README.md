[![Codacy Badge](https://api.codacy.com/project/badge/Grade/3189fb794a294eaa9fdd620072808af1)](https://app.codacy.com/manual/ucalyptus/BS-Nets-Implementation-Pytorch?utm_source=github.com&utm_medium=referral&utm_content=ucalyptus/BS-Nets-Implementation-Pytorch&utm_campaign=Badge_Grade_Dashboard)
# BS-Nets-Implementation-Pytorch [![HitCount](http://hits.dwyl.io/ucalyptus/BS-Nets-Implementation-Pytorch.svg)](http://hits.dwyl.io/ucalyptus/BS-Nets-Implementation-Pytorch)
[![PWC](https://img.shields.io/endpoint.svg?url=https://paperswithcode.com/badge/bs-nets-an-end-to-end-framework-for-band/hyperspectral-image-classification-on-indian)](https://paperswithcode.com/sota/hyperspectral-image-classification-on-indian?p=bs-nets-an-end-to-end-framework-for-band)


BS-Nets: An End-to-End Framework For Band Selection of Hyperspectral Image
* [Read the paper here](https://arxiv.org/pdf/1904.08269v1.pdf)

Click on `dual attention` branch for Dual Attention based approach

## Please :star: the [Repo](https://github.com/ucalyptus/BS-Nets-Implementation-Pytorch) if you liked it.
