# DRL4BS

Code for reproducing results in [Deep Reinforcement Learning for Band Selection in Hyperspectral Image Classification](https://github.com/lcmou/DRL4BS/blob/main/README.md).

If you find it useful and use it in your research, please kindly use the following BibTex entry.
```
@article{DRL4BS,
  title={Deep Reinforcement Learning for Band Selection in Hyperspectral Image Classification},
  author={Mou, Lichao and Saha, Sudipan and Hua, Yuansheng and Bovolo, Francesca and Bruzzone, Lorenzo and Zhu, Xiao Xiang},
  journal={IEEE Transactions on Geoscience and Remote Sensing},
  year={in press}
}
```
