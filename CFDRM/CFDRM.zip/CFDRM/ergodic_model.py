from test import test
from eval import eval
from opts import opts

import os, sys
import pycocotools.coco as coco
from cocoeval import COCOeval
from merge import merge


class HiddenPrints:
    def __enter__(self):
        self._original_stdout = sys.stdout
        sys.stdout = open(os.devnull, 'w')

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout.close()
        sys.stdout = self._original_stdout


for epoch in range(12, 13):
    with HiddenPrints():
        opt = opts().parse()
        opt.load_model = r'exp\WeightPseudoDetection_ResNet18_SD\model_{}.pth'.format(epoch + 1)
        opt.K = 256
        opt.keep_res = True
        test(opt)
    print(opt.load_model)
    # merge(save_path=r'exp\GTDetection')
    # prec, rec, f1 = eval()
    # print('Epoch: %d, Prec: %.5f, Rec: %.5f, F1: %.5f AP: ' % (epoch + 1, prec, rec, f1))
    tool = coco.COCO(r'E:\jqp\data\MOT\DXB\gt.json')
    coco_dets = tool.loadRes(r'exp\WeightPseudoDetection_ResNet18_SD\results.json')
    coco_eval = COCOeval(tool, coco_dets, "bbox")
    coco_eval.evaluate()
    coco_eval.accumulate()
    coco_eval.summarize()
